<?php require __DIR__ . '/auth-admin.php'; ?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" /><meta name="viewport" content="width=device-width,initial-scale=1.0" />
<title>Settings - Senesa Child Center</title>
<link rel="stylesheet" href="dashboard.css" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" />
<style>
  .content{padding:30px}
  .section{ background:#fff; border-radius:12px; box-shadow:0 2px 6px rgba(0,0,0,.08); padding:18px 16px; margin-bottom:16px }
  .row{ display:grid; grid-template-columns:repeat(auto-fit,minmax(220px,1fr)); gap:12px }
  .form-group{ text-align:left }
  .form-group label{ display:block; margin-bottom:6px; color:#555 }
  .form-group input,.form-group textarea{ width:100%; padding:10px; border:1px solid #ddd; border-radius:8px }
  .btn-primary{background:#ff6b6b;color:#fff;border:none;padding:10px 14px;border-radius:8px;cursor:pointer}
  .btn-ghost{background:#fff;border:1px solid #ddd;color:#333;padding:10px 14px;border-radius:8px;cursor:pointer}
  .danger{ background:#ef4444 !important; color:#fff !important; border-color:#ef4444 !important }
</style>
</head>
<body>
  <aside class="sidebar">
    <h2><i class="fas fa-school"></i> Senesa Child Center - Admin</h2>
    <nav>
      <a href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
      <a href="students.php"><i class="fas fa-user-graduate"></i> Enrollments</a>
      <a href="teachers.php"><i class="fas fa-chalkboard-teacher"></i> Teachers</a>
      <a href="programs.php"><i class="fas fa-book-open"></i> Programs</a>
      <a href="gallery.php"><i class="fas fa-images"></i> Gallery</a>
      <a href="books.php" ><i class="fas fa-book"></i> Books</a>
      <a href="messages.php"><i class="fas fa-envelope"></i> Messages</a>
      <a href="users.php"><i class="fas fa-users-cog"></i> Users</a>
      <a href="orders.php"><i class="fas fa-receipt"></i> Orders</a>
      <a href="settings.php" class="active"><i class="fas fa-cog"></i> Settings</a>
    </nav>
  </aside>

  <main class="main-content">
    <header class="topbar">
      <button class="sidebar-toggle"><i class="fas fa-bars"></i></button>
      <h1>Settings</h1>
      <div class="admin-info dropdown">
        <i class="fas fa-user-circle"></i> Admin <i class="fas fa-caret-down"></i>
        <ul class="dropdown-menu">
          <li><a href="profile.php">Profile</a></li>
          <li><a href="change-password.php">Change Password</a></li>
          <li><a href="#" id="logoutBtn">Logout</a></li>
        </ul>
      </div>
      <div id="logoutModal" class="modal modal--confirm">
        <div class="modal-content">
          <span class="close">&times;</span>
          <h3>Confirm Logout</h3>
          <p>Are you sure you want to logout?</p>
          <div class="modal-buttons">
            <button id="confirmLogout" class="btn-danger">Yes, Logout</button>
            <button id="cancelLogout" class="btn-secondary">Cancel</button>
          </div>
        </div>
      </div>
    </header>

    <section class="content">
      <div style="margin-bottom:16px">
        <a href="dashboard.php" class="btn-outline btn-outline-primary"><i class="fas fa-arrow-left"></i> Back</a>
      </div>

      <div class="section">
        <h3 style="margin:0 0 10px">School Info</h3>
        <div class="row">
          <div class="form-group"><label for="schoolEmail">Email</label><input id="schoolEmail" placeholder="senesachildcenter@gmail.com" /></div>
          <div class="form-group"><label for="phone1">Phone 1</label><input id="phone1" placeholder="+94 …" /></div>
          <div class="form-group"><label for="phone2">Phone 2</label><input id="phone2" placeholder="+94 …" /></div>
          <div class="form-group"><label for="hours">Opening Hours</label><input id="hours" placeholder="Mon–Thu 8:00–12:30; Fri 9:00–12:00" /></div>
        </div>
        <div style="margin-top:10px"><button id="saveInfo" class="btn-primary"><i class="fas fa-save"></i> Save</button></div>
      </div>

      <div class="section">
        <h3 style="margin:0 0 10px">Backup & Restore</h3>
        <div style="display:flex;gap:10px;flex-wrap:wrap">
          <button id="downloadBackup" class="btn-ghost"><i class="fas fa-download"></i> Download Backup (JSON)</button>
          <button id="restoreBtn" class="btn-ghost"><i class="fas fa-upload"></i> Restore from JSON</button>
          <input id="restoreInput" type="file" accept="application/json" style="display:none" />
          <button id="clearAll" class="btn-ghost danger"><i class="fas fa-trash"></i> Clear All Data</button>
        </div>
        <p style="color:#6b7280;margin-top:6px">This includes: teachers, enrollments, programs, books, gallery, users, messages, and school info.</p>
      </div>
    </section>

    <footer style="text-align:center;padding:15px;margin-top:auto;background:#fff;box-shadow:0 -2px 5px rgba(0,0,0,.1);">
      &copy; 2025 Senesa Child Center. All rights reserved.
    </footer>
  </main>

<script>
/* shared UI */
const adminInfo=document.querySelector('.admin-info'); const dropdownMenu=adminInfo?.querySelector('.dropdown-menu');
const logoutBtn=document.getElementById('logoutBtn'); const logoutModal=document.getElementById('logoutModal');
const closeLogout=logoutModal?.querySelector('.close'); const confirmLogout=document.getElementById('confirmLogout');
const cancelLogout=document.getElementById('cancelLogout'); const toggleBtn=document.querySelector('.sidebar-toggle');
const sidebar=document.querySelector('.sidebar');
adminInfo?.addEventListener('click',e=>{e.stopPropagation();dropdownMenu?.classList.toggle('show')});
document.addEventListener('click',()=>dropdownMenu?.classList.remove('show'));
logoutBtn?.addEventListener('click',e=>{e.preventDefault(); if(!logoutModal)return; logoutModal.style.display='flex'; dropdownMenu?.classList.remove('show'); document.body.classList.add('modal-open')});
function closeLogoutModal(){ if(!logoutModal)return; logoutModal.style.display='none'; document.body.classList.remove('modal-open') }
closeLogout?.addEventListener('click',closeLogoutModal); cancelLogout?.addEventListener('click',closeLogoutModal);
window.addEventListener('click',e=>{ if(e.target===logoutModal) closeLogoutModal() }); document.addEventListener('keydown',e=>{ if(e.key==='Escape'&&logoutModal?.style.display==='flex') closeLogoutModal() });
confirmLogout?.addEventListener('click',()=>{ document.body.classList.remove('modal-open'); location.href='admin-login.html' });
toggleBtn?.addEventListener('click',()=> sidebar?.classList.toggle('active'));

/* Settings logic */
const INFO_KEY='senesa_school_info_v1';
const ALL_KEYS=[
  'senesa_teachers_v1','senesa_enrollments_v2','senesa_programs_v1','senesa_books_v1','senesa_gallery_v1','senesa_users_v1','senesa_messages_v1','senesa_school_info_v1'
];

// load/save info
const schoolEmail=document.getElementById('schoolEmail'); const phone1=document.getElementById('phone1'); const phone2=document.getElementById('phone2'); const hours=document.getElementById('hours');
(function initInfo(){
  const t=JSON.parse(localStorage.getItem(INFO_KEY)||'{}');
  schoolEmail.value=t.email||'senesachildcenter@gmail.com';
  phone1.value=t.phone1||''; phone2.value=t.phone2||''; hours.value=t.hours||'Mon–Thu 8:00–12:30; Fri 9:00–12:00';
})();
document.getElementById('saveInfo').addEventListener('click',()=>{
  const payload={ email:schoolEmail.value.trim(), phone1:phone1.value.trim(), phone2:phone2.value.trim(), hours:hours.value.trim(), updatedAt:new Date().toISOString() };
  localStorage.setItem(INFO_KEY,JSON.stringify(payload)); alert('Saved.');
});

// backup
document.getElementById('downloadBackup').addEventListener('click',()=>{
  const dump={ exportedAt:new Date().toISOString() };
  ALL_KEYS.forEach(k=> dump[k]=JSON.parse(localStorage.getItem(k)||'null'));
  const blob=new Blob([JSON.stringify(dump,null,2)],{type:'application/json'});
  const a=document.createElement('a'); a.href=URL.createObjectURL(blob); a.download='senesa-backup.json'; a.click(); URL.revokeObjectURL(a.href);
});

// restore
const restoreBtn=document.getElementById('restoreBtn'); const restoreInput=document.getElementById('restoreInput');
restoreBtn.addEventListener('click',()=>restoreInput.click());
restoreInput.addEventListener('change',()=>{
  const f=restoreInput.files[0]; if(!f)return; const r=new FileReader();
  r.onload=()=>{ try{
    const o=JSON.parse(r.result);
    let count=0;
    ALL_KEYS.forEach(k=>{ if(o[k]!==undefined){ localStorage.setItem(k,JSON.stringify(o[k])); count++; }});
    alert('Restored '+count+' collections. Reloading…'); location.reload();
  }catch(e){ alert('Invalid JSON.'); } restoreInput.value=''; };
  r.readAsText(f);
});

// clear all
document.getElementById('clearAll').addEventListener('click',()=>{
  if(confirm('This will delete all local admin data. Continue?')){
    ALL_KEYS.forEach(k=>localStorage.removeItem(k));
    alert('Cleared.'); location.reload();
  }
});
</script>
</body>
</html>
